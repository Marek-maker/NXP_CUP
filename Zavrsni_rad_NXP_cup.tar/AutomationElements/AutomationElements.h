#ifndef AUTOMATION_ELEMENTS_H
#define AUTOMATION_ELEMENTS_H

#include "DT1.h"
#include "I.h"
#include "PDT1.h"
#include "PI.h"
#include "PT1.h"
#include "PT2.h"
#include "PT2cc.h"

#endif // AUTOMATION_ELEMENTS_H